//
//  Jaiminho.h
//  Jaiminho
//
//  Created by Jaison Vieira on 10/11/17.
//  Copyright © 2017 Stone Pagamentos. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Jaiminho.
FOUNDATION_EXPORT double JaiminhoVersionNumber;

//! Project version string for Jaiminho.
FOUNDATION_EXPORT const unsigned char JaiminhoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Jaiminho/PublicHeader.h>


